package com.example.aris_rizaldi.jhotel_android_muhammadarisrizaldi;

import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;

public class SelesaiPesananActivty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selesai_pesanan_activty);
    }
}
