package com.example.aris_rizaldi.jhotel_android_muhammadarisrizaldi;

public class PesananSelesaiRequest {
}
